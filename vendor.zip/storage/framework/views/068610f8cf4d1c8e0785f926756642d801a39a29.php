<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('usuario.update',['id'=> $users->id])); ?>" class="form-validate ">
        <div class="box-body ">
            <?php echo csrf_field(); ?>
            <div class="card mb-4">
                <div class="card-header  ">
                    <i class=" fas fa-table tablecolor"></i> Editar
                </div>
                <div class="card-body">
                    <div class="form-group row ">
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label for="name" class="col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>
                                <input id="description" type="description" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($users->name); ?>" placeholder="Nome" required>
                                <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="telefone" class="col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>
                                <input id="telefone" type="text" data-mask="(00)0000-00000" class="form-control" name="telefone"  value="<?php echo e($users->telefone); ?>">
                                <?php if($errors->has('telefone')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('telefone')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"  value="<?php echo e($users->email); ?>"  placeholder="E-mail" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="Type" class="col-form-label text-md-right"><?php echo e(__('Tipo')); ?></label>
                                <select name="type"  id="type" class=" form-control select2" required>
                                    <?php if($users->type == 'admin'): ?>
                                        <option value="admin" selected>Admin</option>
                                        <option value="user">Usuário</option>
                                        <?php elseif($users->type == 'user'): ?>
                                            <option value="user" selected>Usuário</option>
                                            <option value="admin">Admin</option>
                                        <?php else: ?>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('type')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('type')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-outline-primary">Atualizar</button>
                                <a href="<?php echo e(route('usuario')); ?>" class="btn btn-outline-info">Voltar</a>
                                <?php if($users->id != auth()->user()->id): ?>
                                    <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                        <label class="btn btn-outline-success <?php echo e($users->status == 1 ? 'active' : ''); ?>">
                                            <input type="radio" name="status" value="1"
                                            autocomplete="off" <?php echo e($users->status == 1 ? 'checked' : ''); ?>> Ativo
                                        </label>
                                        <label class="btn btn-outline-danger <?php echo e($users->status == 0 ? 'active' : ''); ?>">
                                            <input type="radio" name="status" value="0"
                                            autocomplete="off" <?php echo e($users->status == 0 ? 'checked' : ''); ?>> Inativo
                                        </label>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
        // Material Select Initialization
        $(document).ready(function() {
            $('.form-control').materialSelect();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/userstable/edit.blade.php ENDPATH**/ ?>