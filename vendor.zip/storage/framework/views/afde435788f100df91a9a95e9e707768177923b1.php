<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('usuario.store')); ?>" class="form-validate">
        <div class="box-body ">
            <?php echo csrf_field(); ?>
            <div class="card mb-4">
                <div class="card-header">   
                    <i class="fas fa-table"></i> Cadastrar
                </div>
                <div class="card-body ">
                    <div class="form-row ">
                        <div class="col-md-3">
                            <div class="form-group ">
                                <label for="name" class="col-form-label text-md-right"><?php echo e(__('Nome')); ?></label>
                                <input id="description" type="description" class=" form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="name" placeholder="Nome" required>
                                <?php if($errors->has('description')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="teledone" class="col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>
                                <input id="impitTelefone" type="text" name="telefone"  data-mask="(00)00000-0000" maxlength="14" class="form-control">
                                <?php if($errors->has('telefone')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('telefone')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="" placeholder="E-mail" required>
                                <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong>Email já cadastrado</strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="Type" class="col-form-label text-md-right"><?php echo e(__('Tipo')); ?></label>
                                <select name="type" id="type" class=" form-control select2" required><br />
                                    <option value="" selected>Selecione um Tipo</option>
                                    <option value="admin">Admin</option>
                                    <option value="user">Usuário</option>
                                </select>
                                <?php if($errors->has('type')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('type')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="password" class="col-form-label text-md-right"><?php echo e(__('Senha')); ?></label>
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" value="" placeholder="Senha" required>
                                <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <button type="submit" class="btn btn-outline-primary">Cadastrar</button>
                                <a href="<?php echo e(route('usuario')); ?>" class="btn btn-outline-info">Voltar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/userstable/new.blade.php ENDPATH**/ ?>