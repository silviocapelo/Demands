<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('cadastro.update', $demand->id)); ?>"method="POST">
        <?php echo csrf_field(); ?>
        <div class="card mb-4">
            <div class="card-header">   
                <i class="fas fa-table"></i> Editar
            </div>
            <div class="card-body">
                <div class="form-group row">
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="NDemanda" class="col-form-label text-md-right"><?php echo e(__('Número')); ?></label>
                            <input id="N_demand" type="text" class="form-control" name="demand_id" value="<?php echo e($demand->demand_id); ?>" placeholdermanda="" required>
                            <?php if($errors->has('demand_id')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('demand_id')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-4">
                        <label for="Type" class="col-form-label text-md-right"><?php echo e(('Atribuido para:')); ?></label>
                        <select type="text" name="selectemail" id="name-name" class="form-control name " required><br/> 
                            <option value="">Selecione</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($demand->user_id == $user->id): ?>
                                    <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="cnpj" class="col-form-label text-md-right"><?php echo e(__('Via de solicitação')); ?></label>
                            <input id="cnpj" type="text" class="form-control cpf_cnpj" name="rout_of_request" value="<?php echo e($demand->rout_of_request); ?>" required>
                            <?php if($errors->has('rout_of_request')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('rout_of_request')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="resolution" class="col-form-label text-md-right"><?php echo e(('Prazo para resolução')); ?></label>
                            <input id="resolution" type="date" class="form-control" name="solution_term" value="<?php echo e($demand->solution_term); ?>" placeholder="" required>
                            <?php if($errors->has('solution_term')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('solution_term')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="cnpj" class="col-form-label text-md-right"><?php echo e(__('Solicitante')); ?></label>
                            <input id="cnpj" type="text" class="form-control" value="<?php echo e($demand->solicitante); ?>" name="solicitante" placeholder="" required>
                            <?php if($errors->has('solicitante')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('solicitante')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="teledone" class="col-form-label text-md-right"><?php echo e(__('Telefone')); ?></label>
                            <input id="impitTelefone" type="text" name="telefone" value="<?php echo e($demand->telefone); ?> "data-mask="(00) 0000-0000" maxlength="14" class="form-control">
                            <?php if($errors->has('telefone')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('telefone')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="teledone" class="col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>
                            <input id="impitTelefone" type="text" name="celular" value="<?php echo e($demand->celular); ?>"  data-mask="(00) 00000-0000" maxlength="14" class="form-control">
                            <?php if($errors->has('celular')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('celular')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>    
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
                            <input id="email" type="email"  class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($demand->email); ?>" placeholder="E-mail" required>
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong>Email já cadastrado</strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cnpj" class="col-form-label text-md-right"><?php echo e(__('Cidade')); ?></label>
                            <input id="city" type="text" class="form-control cpf_cnpj" name="cidade" value="<?php echo e($demand->cidade); ?>" placeholder="" required>
                            <?php if($errors->has('cidade')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('cidade')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-12">
                        <div class="form-group">
                            <style>
                                textarea.foo{
                                    resize:none;
                                }
                            </style>
                            <label for="texto" class="col-form-label text-md-right"><?php echo e(__('Descrição da solicitação')); ?></label>
                            <textarea name=description class="form-control foo" onkeyup="limite_textarea(this.value)" id="textarea" maxlength="2500" required><?php echo e($demand->description); ?></textarea>
                            <span id="count">2500</span> Restantes <br>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">   
                            <style>
                                textarea.foo{
                                    height: 150px; resize: none;
                                    -webkit-box-sizing: border-box;
                                    -moz-box-sizing: border-box;
                                    box-sizing: border-box;
                                    width: 100%; 
                                }
                            </style>
                            <label for="texto" class="col-form-label text-md-right"><?php echo e(__('Desfecho da demanda')); ?></label>
                            <textarea name=outcome  class="form-control foo" onkeyup="limite_textarea(this.value)" id="textarea1" maxlength="2500"><?php echo e($demand->outcome); ?></textarea>
                            <span id="count1">2500</span> Restantes <br>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <?php if(auth()->user()->type == 'user'): ?>
                            <a style="margin-left:"  href="<?php echo e(route('email',['id'=>$demand->id])); ?>" class="btn btn-outline-danger">Finalizar</a>
                            <?php endif; ?>
                                  
                            <?php if($demand->status == '0' && auth()->user()->type == 'user'): ?> 
                                <a style="margin-left:1%"  href="<?php echo e(route('cadastro')); ?>" class="btn btn-outline-info">Voltar</a>                   
                            <?php else: ?>
                                <button type="submit" class="btn btn-outline-primary">Atualizar</button>
                                <a href="<?php echo e(route('cadastro')); ?>" class="btn btn-outline-info">Voltar</a>
                            <?php endif; ?>
                            <?php if(auth()->user()->type == 'admin'): ?>
                                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                    <label class="btn btn-outline-success <?php echo e($demand->status == 1 ? 'active' : ''); ?>">
                                        <input type="radio" name="status" value="1"
                                        autocomplete="off" <?php echo e($demand->status == 1 ? 'checked' : ''); ?>> Aberto
                                    </label>
                                    <label class="btn btn-outline-danger <?php echo e($demand->status == 0 ? 'active' : ''); ?>">
                                        <input type="radio" name="status" value="0"
                                        autocomplete="off" <?php echo e($demand->status == 0 ? 'checked' : ''); ?>> Fechado
                                    </label>
                                </div>
                             <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
        document.getElementById('textarea').onkeyup = function () {

            document.getElementById('count').innerHTML = "" + (2500 - this.value.length);

        };
        document.getElementById('textarea1').onkeyup = function () {
            
            document.getElementById('count1').innerHTML = "" + (2500 - this.value.length);

        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/demands/edit.blade.php ENDPATH**/ ?>