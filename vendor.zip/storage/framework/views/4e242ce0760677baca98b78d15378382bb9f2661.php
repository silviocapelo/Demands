
<hr size="1" />
<img src="https://i.ibb.co/2MJ5QG2/logo50.png" style="color:black"  width="600" height="30"  border="0" /></a>
<table>
  <tr>
    <td style="font-family:tahoma,arial,verdana; font-size:11px; text-align:center" valign="top">
      <a href="https://www.SEUSITE.com.br" target="_blank"><img src="https://i.ibb.co/b7wptqp/LOGO-trans-4.png" width="150" height="150"  border="0" /></a>
    </td>
    <td style="font-family:tahoma,arial,verdana; font-size:16px; padding-left:12px">

      <strong>Demanda nº: <?php echo e($demands->demand_id); ?></strong>
      <br />
      <strong>Responável: <?php echo e($demands->user->name); ?></strong>
      <br />
      <strong>Celular: <?php echo e($demands->user->telefone); ?></strong>
      <br />
      <strong>Solicitante: </strong><?php echo e($demands->solicitante); ?>

      <br />
      <strong>Cidade: </strong><?php echo e($demands->cidade); ?>

      <br /></td> </tr></table>
      <img src="https://i.ibb.co/2MJ5QG2/logo50.png"  width="600" height="30" style="color:blueviolet"  border="0" /></a>
         
                         
         
           
            <?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/mails/emailDemands.blade.php ENDPATH**/ ?>