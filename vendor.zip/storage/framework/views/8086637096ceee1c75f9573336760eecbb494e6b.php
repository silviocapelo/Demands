<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route ('cadastro.store')); ?>"  method="POST">
    <?php echo csrf_field(); ?>
    <div class="card mb-4 ">
        <div class="card-header ">   
            <i class="fas fa-table colorlabel"></i> Cadastrar</div>
            <div class="card-body">
                <div class="form-group row colorlabel">
                    <!--------->
                    <!--------->
                   <div class="col-md-2">
                        <div class="form-group">
                            <label for="NDemanda" class="col-form-label text-md-right"><?php echo e(__('Número')); ?></label>
                            <input id="N_demand" type="text" class="form-control" name="demand_id" placeholdermanda="" required>
                            <?php if($errors->has('demand_id')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('demand_id')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-4">
                        <label for="Type" class="col-form-label  text-md-right"><?php echo e(('Atribuido para:')); ?></label>
                        <select type="text" name="selectemail" id="name-name" class="form-control name " required><br/> 
                            <?php if(auth()->user()->type == 'admin'): ?>  
                            <option value="" selected>Selecione</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> {
                                <option value="<?php echo e(auth()->user()->id); ?>"><?php echo e(auth()->user()->name); ?></option>
                            }
                            <?php endif; ?>
                        </select>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cnpj" class="col-form-label text-md-right"><?php echo e(__('Via de solicitação')); ?></label>
                            <input id="cnpj" type="text" class="form-control" name="rout_of_request" placeholder="" required>
                            <?php if($errors->has('rout_of_request')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('rout_of_request')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="resolution" class="col-form-label text-md-right"><?php echo e(('Prazo para resolução')); ?></label>
                            <input id="resolution" type="date"  class="form-control" name="solution_term" placeholder="" required>
                            <?php if($errors->has('solution_term')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('solution_term')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="cnpj" class="col-form-label text-md-right"><?php echo e(__('Solicitante')); ?></label>
                            <input id="cnpj" type="text" class="form-control " name="solicitante" placeholder="" required>
                            <?php if($errors->has('solicitante')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('solicitante')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="teledone" class="col-form-label text-md-right"><?php echo e(__('Telefone')); ?></label>
                            <input id="impitTelefone" type="text" name="telefone"  data-mask="(00)0000-0000" maxlength="14" class="form-control">
                            <?php if($errors->has('telefone')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('telefone')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="teledone" class="col-form-label text-md-right"><?php echo e(__('Celular')); ?></label>
                            <input id="impitTelefone" type="text" name="celular"  data-mask="(00)00000-0000" maxlength="14" class="form-control">
                            <?php if($errors->has('celular')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('celular')); ?></strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>     
                    <!--------->
                    <!--------->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="email" class="col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="" placeholder="E-mail" required>
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong>Email já cadastrado</strong>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="cit" class="col-form-label text-md-right"><?php echo e(__('Cidade')); ?></label>
                            <input id="city" type="text" class="form-control cpf_cnpj" name="cidade" placeholder="" required>
                            <?php if($errors->has('cidade')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('cidade')); ?></strong>
                            </span>
                            <?php endif; ?> 
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-12">
                        <div class="form-group">
                            <style>
                                textarea.foo{
                                    resize:none;
                                }
                            </style>
                            <label for="texto" class="col-form-label text-md-right"><?php echo e(__('Descrição da solicitação')); ?></label>
                            <textarea name=description class="form-control foo" onkeyup="limite_textarea(this.value)" id="texto" maxlength="2500" required></textarea>
                            <span id="cont">2500</span> Restantes <br>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-12">
                        <div class="form-group">
                            <style>
                                textarea.foo{
                                    height: 150px; resize: none;   
                                    -webkit-box-sizing: border-box;
                                    -moz-box-sizing: border-box;
                                    box-sizing: border-box;
                                    width: 100%;
                                }
                            </style>
                            <label for="texto" class="col-form-label text-md-right"><?php echo e(__('Desfecho da demanda')); ?></label>
                            <textarea name=outcome  class="form-control foo" onkeyup="limite_textarea(this.value)" id="texto" maxlength="2500"></textarea>
                            <span id="cont">2500</span> Restantes <br>
                        </div>
                    </div>
                    <!--------->
                    <!--------->
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-outline-primary">Cadastrar</button>
                        <a href="<?php echo e(route('cadastro')); ?>" class="btn btn-outline-info">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div class="card-footer small text-muted"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/demands/new.blade.php ENDPATH**/ ?>