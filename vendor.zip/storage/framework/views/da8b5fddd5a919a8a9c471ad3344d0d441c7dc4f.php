<?php $__env->startSection('content'); ?>
<!-- DataTables Example -->
    <div class="card mb-3 tablecolor">
    <div class="card-header tablecolor ">
        <i class="fas fa-table"></i> Demandas
    </div>
        <div class=" card-body">
            <div class="table-responsive tablecolor">
                <table id="example"  class="table table-bordered table-hover datatable" style="width:100%">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Descrição</th>
                            <th>Solicitante</th>
                            <th>Atribuido:</th>
                            <th>Telefone</th>
                            <th>Celular</th>
                            <th>Email</th> 
                            <th>Cidade</th>    
                            <th>Criação</th>
                            <th>Prazo</th>
                            <th>Via/Solicitação</th>
                            <th>Status</th>
                            <th>Visualizar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $demands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($demand->demand_id); ?></td>
                                <td><?php echo e($demand->description); ?></td>
                                <td><?php echo e($demand->solicitante); ?></td>
                                <td><?php echo e($demand->user->name); ?></td>
                                <td><?php echo e($demand->telefone); ?></td>
                                <td><?php echo e($demand->celular); ?></td>
                                <td><?php echo e($demand->email); ?></td>
                                <td><?php echo e($demand->cidade); ?></td>
                                <td><?php echo e($demand->created_at->timezone('America/Sao_Paulo')->format('d/m/Y')); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($demand->solution_term))); ?></td>
                                <td><?php echo e($demand->rout_of_request); ?></td>
                                <td>
                                    <?php if($demand->status == 1 ): ?>
                                        <span class="text-success">Aberto</span>
                                    <?php else: ?>
                                        <span class="text-danger">Fechado</span>   
                                    <?php endif; ?>
                                </td>
                                <td class="options">
                                    <div align="center">
                                    <a href="<?php echo e(route('cadastro.edit', $demand->id)); ?>">
                                        <em class="fa fa-fw fa-eye"></em></a></div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/demands/index.blade.php ENDPATH**/ ?>