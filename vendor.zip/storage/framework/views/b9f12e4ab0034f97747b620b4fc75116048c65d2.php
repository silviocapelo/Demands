<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-header ">   
            <i class="fas fa-table"></i> 
        </div>
        <div class="card-body">
            <div class="form-row">
               
                <div class="table-responsive ">
                    <table id="example"  class="table table-bordered table-hover datatable" style="width:100%">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Telefone</th>
                                <th>Tipo</th>
                                <th>status</th>
                                <th>Visualizar</th>  
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->telefone); ?></td>
                                    <td>
                                        <?php if($user->type == 'admin' ): ?>
                                            <span class="text-success">Admin</span>
                                        <?php else: ?>
                                            <span class="text-warning">Usuário</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($user->status == 1 ): ?>
                                            <span class="text-success">Ativo</span>
                                        <?php else: ?>
                                            <span class="text-danger">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="options">
                                        <a href="<?php echo e(route('usuario.edit',['id'=>$user->id])); ?>" ><em class="fa fa-fw fa-eye"></em> Visualizar</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMAS\laragon\www\Demands\resources\views/userstable/index.blade.php ENDPATH**/ ?>